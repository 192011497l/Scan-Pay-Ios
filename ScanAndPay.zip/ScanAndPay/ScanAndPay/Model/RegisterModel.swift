//
//  RegisterModel.swift
//  ScanAndPay
//
//  Created by SAIL on 10/01/24.
//

import Foundation
struct RegisterModel: Codable {
    let status: Bool
    let message: String
}
