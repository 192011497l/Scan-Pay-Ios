//
//  AddEmployeeModel.swift
//  ScanAndPay
//
//  Created by SAIL on 04/01/24.
//

import Foundation

struct AddEmployeeModel: Codable {
    let status: Bool
    let message: String
}
