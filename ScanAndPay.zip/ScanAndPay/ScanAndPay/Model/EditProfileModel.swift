//
//  EditProfileModel.swift
//  ScanAndPay
//
//  Created by SAIL on 29/01/24.
//

import Foundation


// MARK: - Welcome
struct EditProfileModel: Codable {
    let status: Bool
    let message: String
}
