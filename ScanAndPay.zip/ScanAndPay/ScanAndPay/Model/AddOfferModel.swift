//
//  AddOfferModel.swift
//  ScanAndPay
//
//  Created by SAIL on 04/01/24.
//

import Foundation

struct AddOfferModel: Codable {
    let status: Bool
    let message: String
}
