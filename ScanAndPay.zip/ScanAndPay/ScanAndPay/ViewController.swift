//
//  ViewController.swift
//  ScanAndPay
//
//  Created by SAIL on 30/12/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
     
    }


}

