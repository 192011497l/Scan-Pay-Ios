//
//  TabBarController.swift
//  ScanAndPay
//
//  Created by SAIL on 02/01/24.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    



}
